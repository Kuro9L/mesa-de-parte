package com.mesadeparte.mesadeparte;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MesadeparteApplicationTests {

	@Test
	void contextLoads() {
	}

}
